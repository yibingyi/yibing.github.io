### 1.0.0 (2014-12-25):

* [`8b3d874`](https://github.com/npm/normalize-git-url/commit/8b3d874afd14f4cdde65d418e0a35a615c746bba)
  Initial version, with simple tests.
  ([@othiym23](https://github.com/othiym23))
