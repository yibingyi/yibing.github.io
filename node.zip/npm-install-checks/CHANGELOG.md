### v3.0.0 2016-01-12

* Change error messages to be more informative.
* checkEngine, when not in strict mode, now calls back with the error
  object as the second argument instead of warning.
* checkCycle no longer logs when cycle errors are found.

### v2.0.0 2015-01-20

* Remove checking of engineStrict in the package.json
